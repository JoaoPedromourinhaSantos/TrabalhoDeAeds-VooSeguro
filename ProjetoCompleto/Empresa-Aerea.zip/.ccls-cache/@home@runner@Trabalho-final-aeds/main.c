//INTEGRANTES!!!!!!!!!!!!!!!!!!!!!
//HEYTOR LAS'CASAS E JOÃO PEDRO MOURA SANTOS
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

//passageiros belo horizonte para rio de janeiro.
void PBH_RJ();
//função menu inicial
void apresentacao();
int pesquisacpf();
int pesquisanome();
int cadastroPassageiro();
int excluirPassageiroRio();
int mostrafiladeespera();

// funçoes PASSAGEIROS BH PARA SP
void PBH_SP();
int pesquisacpfSP();
int pesquisanomeSP();
int cadastroPassageiroSP();
int excluirPassageiroSP();
int mostrafiladeesperaSP();

//funções brasilia
void PBH_BRASILIA();
int pesquisacpfBRASILIA();
int pesquisanomeBRASILIA();
int cadastroPassageiroBRASILIA();
int excluirPassageiroBRASILIA();
int mostrafiladeesperaBRASILIA();
  
struct Passageiro{
    char CPF[20];    
    char nome[100];
    char Endereco[100];
    char Telefone[15];
    char numeroPassagem[10];
    char numeroPoltrona[10];
    char numeroVoo[10];
    char horario[8];
  };



int main() {

  //linguagem PT-BR
  setlocale(LC_ALL,"");

  int numerovoo;
  int escolha;
  int voodesejado;
  char Buscacpf[20];

//chamando o menu de voos
      apresentacao();
      scanf("%d", &voodesejado);
  
printf("\n\n\n\n\n\n\n\n\n\n");

switch (voodesejado){
  case 1:

printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA RIO                             -|\n");
printf("-|                             OPÇÕES                                -|\n");
printf("-|                                                                   -|\n");
printf("-|          (1) = Mostrar a lista completa dos passageiros           -|\n");
printf("-|                                                                   -|\n");
printf("-|      (2) = Pesquisar um passageiro na lista do voo pelo CPF       -|\n");
printf("-|                                                                   -|\n");
printf("-|        (3) = Pesquisar um passageiro na lista pelo nome           -|\n");
printf("-|                                                                   -|\n");
printf("-|          (4) = Cadastrar um passageiro na lista do voo            -|\n");
printf("-|                                                                   -|\n");
printf("-|           (5) = Excluir um passageiro da lista do voo             -|\n");
printf("-|                                                                   -|\n");
printf("-|         (6) = Mostrar a fila de espera dos passageiros do voo     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|                          (9) = SAIR                               -|\n");
printf("-|                   -----------------------------                   -|\n");
printf("-|                         DIGITE SUA OPÇÃO!                         -|\n");
printf("-|--------------------------------------------------------------------|\n");
printf("-|                __  _                                               |\n");
printf("-|                !! `/ |                                             |\n");
printf("-|                 !!__`!                                             |\n");
printf("-|                 / ,' `-.__________________                         |\n");
printf("-|                '-'!_____                LI`-.                      |\n");
printf("-|                   <____()-=O=O=O=O=O=[]====--)                     |\n");
printf("-|                     `.___ ,-----,_______...-'                      |\n");
printf("-|                          /    .'                                   |\n");
printf("-|                         /   .'                                     |\n");
printf("-|                        /  .'                                       |\n");
printf("-|                        `-'                                         |\n");    
printf("-|--------------------------------------------------------------------|\n");

scanf("%d", &escolha);
printf("\n\n\n\n");

    
switch (escolha){

  case 1:
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA RIO                             -|\n");  
printf("-|                      LISTA DE PASSAGEIROS                         -|\n");
printf("-|                                                                   -|\n");
printf("-|--------------------------------------------------------------------|\n");

    PBH_RJ();

break;
  
  case 2: 
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA RIO                             -|\n");  
printf("-|                      PESQUISA POR PASSAGEIROS                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|                      DIGITE O CPF DO PASSAGEIRO                   -|\n");
printf("-|                                                                   -|\n");
printf("-|                              EXEMPLO                              -|\n");
printf("-|                           283.885.558-60                          -|\n");
printf("-|--------------------------------------------------------------------|\n");

pesquisacpf();
 
  break;

  case 3:
    
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA RIO                             -|\n");  
printf("-|                      PESQUISA POR PASSAGEIROS                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|                      DIGITE O NOME DO PASSAGEIRO                  -|\n");
printf("-|                                                                   -|\n");
printf("-|                              EXEMPLO                              -|\n");
printf("-|                              Adriana                              -|\n");
printf("-|--------------------------------------------------------------------|\n");

pesquisanome();
    
  break;

  case 4:

printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA RIO                             -|\n");  
printf("-|                       CADASTRAR PASSAGEIROS                       -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|--------------------------------------------------------------------|\n");

cadastroPassageiro();

break;

  case 5:
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA RIO                             -|\n");  
printf("-|                       EXCLUIR PASSAGEIROS                         -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|--------------------------------------------------------------------|\n");

excluirPassageiroRio();

  case 6:
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA RIO                             -|\n");  
printf("-|                      LISTA DE PASSAGEIROS                         -|\n");
printf("-|                          FILA DE ESPERA                           -|\n");
printf("-|--------------------------------------------------------------------|\n");

mostrafiladeespera();
  
  break;

  case 9:
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");  
printf("-|                     AGRADEÇEMOS A PREFERENCIA                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|--------------------------------------------------------------------|\n");

    printf("\n\n\n");
    main();
    
  break;
  }    
    
  break;
  case 2:
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA SP                              -|\n");
printf("-|                             OPÇÕES                                -|\n");
printf("-|                                                                   -|\n");
printf("-|          (1) = Mostrar a lista completa dos passageiros           -|\n");
printf("-|                                                                   -|\n");
printf("-|      (2) = Pesquisar um passageiro na lista do voo pelo CPF       -|\n");
printf("-|                                                                   -|\n");
printf("-|        (3) = Pesquisar um passageiro na lista pelo nome           -|\n");
printf("-|                                                                   -|\n");
printf("-|          (4) = Cadastrar um passageiro na lista do voo            -|\n");
printf("-|                                                                   -|\n");
printf("-|           (5) = Excluir um passageiro da lista do voo             -|\n");
printf("-|                                                                   -|\n");
printf("-|         (6) = Mostrar a fila de espera dos passageiros do voo     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|                          (9) = SAIR                               -|\n");
printf("-|                   -----------------------------                   -|\n");
printf("-|                         DIGITE SUA OPÇÃO!                         -|\n");
printf("-|--------------------------------------------------------------------|\n");
printf("-|                __  _                                               |\n");
printf("-|                !! `/ |                                             |\n");
printf("-|                 !!__`!                                             |\n");
printf("-|                 / ,' `-.__________________                         |\n");
printf("-|                '-'!_____                LI`-.                      |\n");
printf("-|                   <____()-=O=O=O=O=O=[]====--)                     |\n");
printf("-|                     `.___ ,-----,_______...-'                      |\n");
printf("-|                          /    .'                                   |\n");
printf("-|                         /   .'                                     |\n");
printf("-|                        /  .'                                       |\n");
printf("-|                        `-'                                         |\n");    
printf("-|--------------------------------------------------------------------|\n");
    
scanf("%d", &escolha);
  printf("\n\n\n");

switch (escolha){
  case 1:
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA SP                              -|\n");  
printf("-|                      LISTA DE PASSAGEIROS                         -|\n");
printf("-|                                                                   -|\n");
printf("-|--------------------------------------------------------------------|\n");

    PBH_SP();

break;
  
  case 2: 
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA SP                              -|\n");  
printf("-|                      PESQUISA POR PASSAGEIROS                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|                      DIGITE O CPF DO PASSAGEIRO                   -|\n");
printf("-|                                                                   -|\n");
printf("-|                              EXEMPLO                              -|\n");
printf("-|                           283.885.558-60                          -|\n");
printf("-|--------------------------------------------------------------------|\n");

pesquisacpfSP();
 
  break;

  case 3:
    
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA SP                              -|\n");  
printf("-|                      PESQUISA POR PASSAGEIROS                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|                      DIGITE O NOME DO PASSAGEIRO                  -|\n");
printf("-|                                                                   -|\n");
printf("-|                              EXEMPLO                              -|\n");
printf("-|                              Adriana                              -|\n");
printf("-|--------------------------------------------------------------------|\n");

pesquisanomeSP();
    
  break;

  case 4:

printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA SP                              -|\n");  
printf("-|                       CADASTRAR PASSAGEIROS                       -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|--------------------------------------------------------------------|\n");

cadastroPassageiroSP();

break;

  case 5:
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA SP                              -|\n");  
printf("-|                       EXCLUIR PASSAGEIROS                         -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|--------------------------------------------------------------------|\n");

excluirPassageiroSP();

  case 6:
    
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA SP                              -|\n");  
printf("-|                      LISTA DE PASSAGEIROS                         -|\n");
printf("-|                          FILA DE ESPERA                           -|\n");
printf("-|--------------------------------------------------------------------|\n");
mostrafiladeesperaSP();
  break;

  case 9:
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");  
printf("-|                     AGRADEÇEMOS A PREFERENCIA                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|--------------------------------------------------------------------|\n");

    printf("\n\n\n");
    main();
    
  break;
  
  }
    
  break;
  case 3:
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                         BH PARA BRASILIA                          -|\n");
printf("-|                             OPÇÕES                                -|\n");
printf("-|                                                                   -|\n");
printf("-|          (1) = Mostrar a lista completa dos passageiros           -|\n");
printf("-|                                                                   -|\n");
printf("-|      (2) = Pesquisar um passageiro na lista do voo pelo CPF       -|\n");
printf("-|                                                                   -|\n");
printf("-|        (3) = Pesquisar um passageiro na lista pelo nome           -|\n");
printf("-|                                                                   -|\n");
printf("-|          (4) = Cadastrar um passageiro na lista do voo            -|\n");
printf("-|                                                                   -|\n");
printf("-|           (5) = Excluir um passageiro da lista do voo             -|\n");
printf("-|                                                                   -|\n");
printf("-|         (6) = Mostrar a fila de espera dos passageiros do voo     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|                          (9) = SAIR                               -|\n");
printf("-|                   -----------------------------                   -|\n");
printf("-|                         DIGITE SUA OPÇÃO!                         -|\n");
printf("-|--------------------------------------------------------------------|\n");
printf("-|                __  _                                               |\n");
printf("-|                !! `/ |                                             |\n");
printf("-|                 !!__`!                                             |\n");
printf("-|                 / ,' `-.__________________                         |\n");
printf("-|                '-'!_____                LI`-.                      |\n");
printf("-|                   <____()-=O=O=O=O=O=[]====--)                     |\n");
printf("-|                     `.___ ,-----,_______...-'                      |\n");
printf("-|                          /    .'                                   |\n");
printf("-|                         /   .'                                     |\n");
printf("-|                        /  .'                                       |\n");
printf("-|                        `-'                                         |\n");    
printf("-|--------------------------------------------------------------------|\n");
    
scanf("%d", &escolha);
  printf("\n\n\n");

switch(escolha){

  case 1: 
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                         BH PARA BRASILA                           -|\n");  
printf("-|                       LISTA DE PASSAGEIROS                        -|\n");
printf("-|                                                                   -|\n");
printf("-|--------------------------------------------------------------------|\n");
  PBH_BRASILIA();
  break;

  case 2: 
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                         BH PARA BRASILIA                          -|\n");  
printf("-|                      PESQUISA POR PASSAGEIROS                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|                      DIGITE O CPF DO PASSAGEIRO                   -|\n");
printf("-|                                                                   -|\n");
printf("-|                              EXEMPLO                              -|\n");
printf("-|                           283.885.558-60                          -|\n");
printf("-|--------------------------------------------------------------------|\n");

pesquisacpfBRASILIA();
  break;

  case 3:
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                           BH PARA BRASILIA                        -|\n");  
printf("-|                      PESQUISA POR PASSAGEIROS                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|                      DIGITE O NOME DO PASSAGEIRO                  -|\n");
printf("-|                                                                   -|\n");
printf("-|                              EXEMPLO                              -|\n");
printf("-|                              Adriana                              -|\n");
printf("-|--------------------------------------------------------------------|\n");
  pesquisanomeBRASILIA();
  break;

  case 4:
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                         BH PARA BRASILIA                          -|\n");  
printf("-|                       CADASTRAR PASSAGEIROS                       -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|--------------------------------------------------------------------|\n");
    
 cadastroPassageiroBRASILIA();
    
  break;

  case 5:
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                        BH PARA BRASILIA                           -|\n");  
printf("-|                       EXCLUIR PASSAGEIROS                         -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|--------------------------------------------------------------------|\n");
excluirPassageiroBRASILIA();
  break;

  case 6: 
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                         BH PARA BRASILIA                          -|\n");  
printf("-|                       LISTA DE PASSAGEIROS                        -|\n");
printf("-|                          FILA DE ESPERA                           -|\n");
printf("-|--------------------------------------------------------------------|\n");
    mostrafiladeesperaBRASILIA();
  break;

  case 9:
printf("-|--------------------------------------------------------------------|\n");
printf("-|               ------------------------------------                -|\n");
printf("-|                     EMPRESA AEREA QUEDA LIVRE                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");  
printf("-|                     AGRADEÇEMOS A PREFERENCIA                     -|\n");
printf("-|                                                                   -|\n");
printf("-|                                                                   -|\n");
printf("-|--------------------------------------------------------------------|\n");

    printf("\n\n\n");
    main();
    
  break;
  
}
  default:
  printf("Digite novamente!");
   printf("\n\n\n");
    main();

}
  return 0;
}









//funções
void apresentacao (){
printf("-|--------------------------------------------------------|\n");
printf("-|            ------------------------------              |\n");
printf("-|               EMPRESA AEREA QUEDA LIVRE               -|\n");
printf("-|            DIGITE O VOO QUE DESEJA SEGUIR!            -|\n");
printf("-|                                                       -|\n");
printf("-|                                                       -|\n");
printf("-|                                                       -|\n");
printf("-|                (1) = BH PARA RIO                      -|\n");
printf("-|                                                       -|\n");
printf("-|                (2) = BH PARA SP                       -|\n");
printf("-|                                                       -|\n");
printf("-|                (3) = BH PARA BRASÍLIA                 -|\n");
printf("-|                                                       -|\n");
printf("-|                                                       -|\n");
printf("-|                                                       -|\n");
printf("-|            ------------------------------             -|\n");
printf("-|            DIGITE O VOO QUE DESEJA SEGUIR!            -|\n");
printf("-|--------------------------------------------------------|\n");

};


//ler passageiros voo de bh para rio de janeiro
void PBH_RJ(){

  FILE *ler = fopen("voobhrio.txt", "r");


  while (!feof(ler)){
    struct Passageiro pessoas;

    fscanf(ler, "%s", pessoas.CPF);
    fscanf(ler, "%s", pessoas.nome);
    fscanf(ler, "%s", pessoas.Endereco);
    fscanf(ler, "%s", pessoas.Telefone);
    fscanf(ler, "%s", pessoas.numeroPassagem);
    fscanf(ler, "%s", pessoas.numeroPoltrona);
    fscanf(ler, "%s", pessoas.numeroVoo);
    fscanf(ler, "%s", pessoas.horario);

        // Imprimir os dados lidos
  printf("\n");
  printf("\n=============================================================");
  printf("\nCPF: %s", pessoas.CPF);
  printf("\nNOME: %s", pessoas.nome);
  printf("\nEndereço: %s", pessoas.Endereco);
  printf("\nTELEFONE: %s", pessoas.Telefone);
  printf("\nNUMERO DE PASSAGEM: %s", pessoas.numeroPassagem);
  printf("\nNUMERO DE POLTRONA: %s", pessoas.numeroPoltrona);
  printf("\nNUMERO VOO: %s", pessoas.numeroVoo);
  printf("\nHORÁRIO DO VOO: %s", pessoas.horario);
  printf("\n=============================================================");


}
fclose(ler);
printf("\n\n\n");
main();
};

int pesquisacpf() {
 FILE *ler = fopen("voobhrio.txt", "r");
    
    if (ler == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }
    
    struct Passageiro pessoas[10];
    int numPassageiros = 0;  

    while (numPassageiros < 10 && fscanf(ler, "%s %s %s %s %s %s %s %s",
     pessoas[numPassageiros].CPF,
    pessoas[numPassageiros].nome,
    pessoas[numPassageiros].Endereco,
    pessoas[numPassageiros].Telefone,
    pessoas[numPassageiros].numeroPassagem,
     pessoas[numPassageiros].numeroPoltrona,
     pessoas[numPassageiros].numeroVoo,
      pessoas[numPassageiros].horario) == 8) {
        numPassageiros++;
    }
  
    char cpf[20];
    printf("Digite o CPF do passageiro: ");
    scanf("%s", cpf);
    cpf[strcspn(cpf, "\n")] = '\0';
    getchar();
    int encontrou = 0;
    
    for (int i = 0; i < numPassageiros; i++) {
        if (strcmp(pessoas[i].CPF, cpf) == 0) {  
   printf("\n===================================================\n");
  printf("Nome: %s\n", pessoas[i].nome);
   printf("Endereço: %s\n", pessoas[i].Endereco);
   printf("Telefone: %s\n", pessoas[i].Telefone);
   printf("Número da Passagem: %s\n", pessoas[i].numeroPassagem);
    printf("Número da Poltrona: %s\n", pessoas[i].numeroPoltrona);
    printf("Número do Voo: %s\n", pessoas[i].numeroVoo);
    printf("Horário: %s\n", pessoas[i].horario);
     printf("====================================================");
       encontrou = 1;
        break;
        } 
    }
    
   if (encontrou != 1){
      printf("Passageiro não encontrado!\n");
   }
    
fclose(ler);

    // Chamando o main
 printf("\n\n\n");
main();
    
return 0;
}

int pesquisanome(){
  FILE *ler = fopen("voobhrio.txt", "r");
    
if (ler == NULL) {
  printf("Erro ao abrir o arquivo.\n");
  return 1;
    }
    
    struct Passageiro pessoas[10];
    int numPassageiros = 0;  // Corrigido para iniciar em 0

    while (numPassageiros < 10 && fscanf(ler, "%s %s %s %s %s %s %s %s",
  pessoas[numPassageiros].CPF,
  pessoas[numPassageiros].nome,
  pessoas[numPassageiros].Endereco,
  pessoas[numPassageiros].Telefone,
  pessoas[numPassageiros].numeroPassagem,
  pessoas[numPassageiros].numeroPoltrona,
  pessoas[numPassageiros].numeroVoo,
  pessoas[numPassageiros].horario) == 8) {
        numPassageiros++;
    }
  
char nome[20];
  printf("Digite o NOME do passageiro: ");
  scanf("%s", nome);
  nome[strcspn(nome, "\n")] = '\0';
  getchar();
  int encontrou = 0;
for (int i = 0; i < numPassageiros; i++) {
  if (strcmp(pessoas[i].nome, nome) == 0) {  
    printf("\n===================================================\n");
    printf("CPF: %s\n", pessoas[i].CPF);
    printf("Nome: %s\n", pessoas[i].nome);
    printf("Endereço: %s\n", pessoas[i].Endereco);
    printf("Telefone: %s\n", pessoas[i].Telefone);
    printf("Número da Passagem: %s\n", pessoas[i].numeroPassagem);
    printf("Número da Poltrona: %s\n", pessoas[i].numeroPoltrona);
    printf("Número do Voo: %s\n", pessoas[i].numeroVoo);
    printf("Horário: %s\n", pessoas[i].horario);
    printf("\n===================================================\n");
    encontrou =1;
    break;
  }  
}
if (encontrou != 1){
  printf("passageiro não encontrado!");
}
fclose(ler);

// chamando o main!
printf("\n\n\n");
main();
return 0;
}

int cadastroPassageiro() {
    FILE *ler = fopen("voobhrio.txt", "r");
    FILE *ver = fopen("esperabhrio.txt", "r");

    struct Passageiro espera[15];


    if (ler != NULL) {
        // Verificar se a lista de passageiros está cheia
        fseek(ler, 0, SEEK_END);
        long tamanhoListaPassageiros = ftell(ler);
        int numPassageiros = tamanhoListaPassageiros / sizeof(espera->numeroPoltrona);
        if (numPassageiros >= 10) {
             printf("\n==========================================================================\n");
            printf("Lista de passageiros cheia. O passageiro será incluído na fila de espera.\n");

    if (ver != NULL) {
        // Verificar se a fila de espera está cheia
        fseek(ver, 0, SEEK_END);
        long tamanhoFilaEspera = ftell(ver);
        int numFilaEspera = tamanhoFilaEspera / sizeof(espera->numeroPassagem);
        if (numFilaEspera >= 5) {
            printf("Fila de espera cheia. O passageiro não pode ser cadastrado.\n");
             printf("\n==========================================================================\n");
            fclose(ver);
            return 1;
        }
    }
            fclose(ler);
            fclose(ver);
            return 1;
        }
    }
    
    struct Passageiro novoPassageiro;
    
    printf("Digite o CPF do passageiro: ");
    scanf("%s", novoPassageiro.CPF);
    getchar();
  
    printf("Digite o nome do passageiro: ");
    scanf("%s", novoPassageiro.nome);
    getchar();
  
    printf("Digite o endereço do passageiro: ");
    scanf("%s", novoPassageiro.Endereco);
    getchar();
  
    printf("Digite o telefone do passageiro: ");
    scanf("%s", novoPassageiro.Telefone);
    getchar();
  
    printf("Digite o número da passagem do passageiro: ");
    scanf("%s", novoPassageiro.numeroPassagem);
    getchar();
  
    printf("Digite o número da poltrona do passageiro: ");
    scanf("%s", novoPassageiro.numeroPoltrona);
    getchar();
  
    printf("Digite o número do voo do passageiro: ");
    scanf("%s", novoPassageiro.numeroVoo);
    getchar();
  
    printf("Digite o horário do voo do passageiro: ");
    scanf("%s", novoPassageiro.horario);
    getchar();
  
    printf("Passageiro cadastrado com sucesso!\n");

  
    fclose(ler);
    fclose(ver);

  // chamando o main!
printf("\n\n\n");
main();
  
    return 0;
}

// Função para excluir um passageiro da lista de determinado voo
int excluirPassageiroRio() {
    char cpfRemovido[12];
    int mostrar;
    printf("Qual o CPF do passageiro que será removido?\n");
    scanf("%s", cpfRemovido);

    FILE* ler = fopen("voobhrio.txt", "r");
    if (ler == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }

    struct Passageiro pessoas[50];
    int numPassageiros = 0;
    int encontrou = 0;

    // Ler os passageiros do arquivo e procurar o passageiro a ser removido
    while (fscanf(ler, "%s %s %s %s %s %s %s %s",
                  pessoas[numPassageiros].CPF,
                  pessoas[numPassageiros].nome,
                  pessoas[numPassageiros].Endereco,
                  pessoas[numPassageiros].Telefone,
                  pessoas[numPassageiros].numeroPassagem,
                  pessoas[numPassageiros].numeroPoltrona,
                  pessoas[numPassageiros].numeroVoo,
                  pessoas[numPassageiros].horario) == 8 && numPassageiros < 50) {
        if (strcmp(pessoas[numPassageiros].CPF, cpfRemovido) == 0) {
            printf("\n\n\n");
            printf("PASSAGEIRO ENCONTRADO:\n\n");
            printf("|===================================================|\n");
            printf("CPF: %s\n", pessoas[numPassageiros].CPF);
            printf("Nome: %s\n", pessoas[numPassageiros].nome);
            printf("Endereço: %s\n", pessoas[numPassageiros].Endereco);
            printf("Telefone: %s\n", pessoas[numPassageiros].Telefone);
            printf("Número da Passagem: %s\n", pessoas[numPassageiros].numeroPassagem);
            printf("Número da Poltrona: %s\n", pessoas[numPassageiros].numeroPoltrona);
            printf("Número do Voo: %s\n", pessoas[numPassageiros].numeroVoo);
            printf("Horário: %s\n", pessoas[numPassageiros].horario);
            printf("|===================================================|\n");
            encontrou = 1;
            break;
        }
        numPassageiros++;
    }

    fclose(ler);

    if (!encontrou) {
        printf("Passageiro não encontrado.\n");
        // Chamando o main
        printf("\n\n\n");
        main();
        return 0;
    }

    FILE* escrever = fopen("voobhrio.txt", "w");
    if (escrever == NULL) {
        printf("Erro ao abrir o arquivo para reescrever a lista de passageiros.\n");
        return 1;
    }

    for (int i = 0; i < numPassageiros; i++) {
        if (strcmp(pessoas[i].CPF, cpfRemovido) != 0) {
            fprintf(escrever, "%s %s %s %s %s %s %s %s\n",
                    pessoas[i].CPF,
                    pessoas[i].nome,
                    pessoas[i].Endereco,
                    pessoas[i].Telefone,
                    pessoas[i].numeroPassagem,
                    pessoas[i].numeroPoltrona,
                    pessoas[i].numeroVoo,
                    pessoas[i].horario);
        }
    }

    fclose(escrever);

    printf("Passageiro removido com sucesso!\n");

    printf("Mostrar lista de passageiros? Sim = 1 / Não = 0: ");
    scanf("%d", &mostrar);
    if (mostrar) {
        ler = fopen("voobhrio.txt", "r");
        if (ler == NULL) {
            printf("Erro ao abrir o arquivo.\n");
            return 1;
        }

        printf("LISTA DE PASSAGEIROS:\n");

        numPassageiros = 0;
        while (fscanf(ler, "%s %s %s %s %s %s %s %s",
                      pessoas[numPassageiros].CPF,
                      pessoas[numPassageiros].nome,
                      pessoas[numPassageiros].Endereco,
                      pessoas[numPassageiros].Telefone,
                      pessoas[numPassageiros].numeroPassagem,
                      pessoas[numPassageiros].numeroPoltrona,
                      pessoas[numPassageiros].numeroVoo,
                      pessoas[numPassageiros].horario) == 8 && numPassageiros < 50) {
            printf("\n\n\n");
            printf("PASSAGEIRO:\n\n");
            printf("|===================================================|\n");
            printf("CPF: %s\n", pessoas[numPassageiros].CPF);
            printf("Nome: %s\n", pessoas[numPassageiros].nome);
            printf("Endereço: %s\n", pessoas[numPassageiros].Endereco);
            printf("Telefone: %s\n", pessoas[numPassageiros].Telefone);
            printf("Número da Passagem: %s\n", pessoas[numPassageiros].numeroPassagem);
            printf("Número da Poltrona: %s\n", pessoas[numPassageiros].numeroPoltrona);
            printf("Número do Voo: %s\n", pessoas[numPassageiros].numeroVoo);
            printf("Horário: %s\n", pessoas[numPassageiros].horario);
            printf("|===================================================|\n");
            numPassageiros++;
        }

        fclose(ler);
    }

    // Chamando o main
    printf("\n\n\n");
    main();

    return 0;
}

int mostrafiladeespera(){
  FILE *ler = fopen("esperabhrio.txt", "r");


  while (!feof(ler)){
    struct Passageiro pessoas;

    fscanf(ler, "%s", pessoas.CPF);
    fscanf(ler, "%s", pessoas.nome);
    fscanf(ler, "%s", pessoas.Endereco);
    fscanf(ler, "%s", pessoas.Telefone);
    fscanf(ler, "%s", pessoas.numeroPassagem);
    fscanf(ler, "%s", pessoas.numeroPoltrona);
    fscanf(ler, "%s", pessoas.numeroVoo);
    fscanf(ler, "%s", pessoas.horario);

        // Imprimir os dados lidos
  printf("\n");
  printf("\n======================================================");
  printf("\nCPF: %s", pessoas.CPF);
  printf("\nNOME: %s", pessoas.nome);
  printf("\nEndereço: %s", pessoas.Endereco);
  printf("\nTELEFONE: %s", pessoas.Telefone);
  printf("\nNUMERO DE PASSAGEM: %s", pessoas.numeroPassagem);
  printf("\nNUMERO DE POLTRONA: %s", pessoas.numeroPoltrona);
  printf("\nNUMERO VOO: %s", pessoas.numeroVoo);
  printf("\nHORÁRIO DO VOO: %s", pessoas.horario);
  printf("\n======================================================");

}
fclose(ler);
printf("\n\n\n");
main();
  return 0;
};


// VOOS DE SP

void PBH_SP(){
    FILE *ler = fopen("voobhsp.txt", "r");


  while (!feof(ler)){
    struct Passageiro pessoas;

    fscanf(ler, "%s", pessoas.CPF);
    fscanf(ler, "%s", pessoas.nome);
    fscanf(ler, "%s", pessoas.Endereco);
    fscanf(ler, "%s", pessoas.Telefone);
    fscanf(ler, "%s", pessoas.numeroPassagem);
    fscanf(ler, "%s", pessoas.numeroPoltrona);
    fscanf(ler, "%s", pessoas.numeroVoo);
    fscanf(ler, "%s", pessoas.horario);

        // Imprimir os dados lidos
  printf("\n");
  printf("\n=============================================================");
  printf("\nCPF: %s", pessoas.CPF);
  printf("\nNOME: %s", pessoas.nome);
  printf("\nEndereço: %s", pessoas.Endereco);
  printf("\nTELEFONE: %s", pessoas.Telefone);
  printf("\nNUMERO DE PASSAGEM: %s", pessoas.numeroPassagem);
  printf("\nNUMERO DE POLTRONA: %s", pessoas.numeroPoltrona);
  printf("\nNUMERO VOO: %s", pessoas.numeroVoo);
  printf("\nHORÁRIO DO VOO: %s", pessoas.horario);
  printf("\n=============================================================");


}
fclose(ler);
printf("\n\n\n");
main();
};

int pesquisacpfSP() {
    FILE *ler = fopen("voobhsp.txt", "r");
    
    if (ler == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }
    
    struct Passageiro pessoas[10];
    int numPassageiros = 0;  

    while (numPassageiros < 10 && fscanf(ler, "%s %s %s %s %s %s %s %s",
     pessoas[numPassageiros].CPF,
    pessoas[numPassageiros].nome,
    pessoas[numPassageiros].Endereco,
    pessoas[numPassageiros].Telefone,
    pessoas[numPassageiros].numeroPassagem,
     pessoas[numPassageiros].numeroPoltrona,
     pessoas[numPassageiros].numeroVoo,
      pessoas[numPassageiros].horario) == 8) {
        numPassageiros++;
    }
  
    char cpf[20];
    printf("Digite o CPF do passageiro: ");
    scanf("%s", cpf);
    cpf[strcspn(cpf, "\n")] = '\0';
    getchar();
    int encontrou = 0;
    
    for (int i = 0; i < numPassageiros; i++) {
        if (strcmp(pessoas[i].CPF, cpf) == 0) {  
   printf("\n===================================================\n");
  printf("Nome: %s\n", pessoas[i].nome);
   printf("Endereço: %s\n", pessoas[i].Endereco);
   printf("Telefone: %s\n", pessoas[i].Telefone);
   printf("Número da Passagem: %s\n", pessoas[i].numeroPassagem);
    printf("Número da Poltrona: %s\n", pessoas[i].numeroPoltrona);
    printf("Número do Voo: %s\n", pessoas[i].numeroVoo);
    printf("Horário: %s\n", pessoas[i].horario);
     printf("====================================================");
       encontrou = 1;
        break;
        } 
    }
    
   if (encontrou != 1){
      printf("Passageiro não encontrado!\n");
   }
    
fclose(ler);

    // Chamando o main
 printf("\n\n\n");
main();
    
return 0;
}

int pesquisanomeSP(){
  FILE *ler = fopen("voobhsp.txt", "r");
    
if (ler == NULL) {
  printf("Erro ao abrir o arquivo.\n");
  return 1;
    }
    
    struct Passageiro pessoas[10];
    int numPassageiros = 0;  // Corrigido para iniciar em 0

    while (numPassageiros < 10 && fscanf(ler, "%s %s %s %s %s %s %s %s",
  pessoas[numPassageiros].CPF,
  pessoas[numPassageiros].nome,
  pessoas[numPassageiros].Endereco,
  pessoas[numPassageiros].Telefone,
  pessoas[numPassageiros].numeroPassagem,
  pessoas[numPassageiros].numeroPoltrona,
  pessoas[numPassageiros].numeroVoo,
  pessoas[numPassageiros].horario) == 8) {
        numPassageiros++;
    }
  
char nome[20];
  printf("Digite o NOME do passageiro: ");
  scanf("%s", nome);
  nome[strcspn(nome, "\n")] = '\0';
  getchar();
  int encontrou = 0;
for (int i = 0; i < numPassageiros; i++) {
  if (strcmp(pessoas[i].nome, nome) == 0) { 
    printf("\n===================================================\n");
    printf("CPF: %s\n", pessoas[i].CPF);
    printf("Nome: %s\n", pessoas[i].nome);
    printf("Endereço: %s\n", pessoas[i].Endereco);
    printf("Telefone: %s\n", pessoas[i].Telefone);
    printf("Número da Passagem: %s\n", pessoas[i].numeroPassagem);
    printf("Número da Poltrona: %s\n", pessoas[i].numeroPoltrona);
    printf("Número do Voo: %s\n", pessoas[i].numeroVoo);
    printf("Horário: %s\n", pessoas[i].horario);
    printf("\n===================================================\n");
    encontrou =1;
    break;
  }  
}
if (encontrou != 1){
  printf("passageiro não encontrado!");
}
fclose(ler);

// chamando o main!
printf("\n\n\n");
main();
return 0;
}

int cadastroPassageiroSP() {
    FILE *ler = fopen("voobhsp.txt", "r");
    FILE *ver = fopen("esperabhsp.txt", "r");

    struct Passageiro espera[15];


    if (ler != NULL) {
        // Verificar se a lista de passageiros está cheia
        fseek(ler, 0, SEEK_END);
        long tamanhoListaPassageiros = ftell(ler);
        int numPassageiros = tamanhoListaPassageiros / sizeof(espera->numeroPoltrona);
        if (numPassageiros >= 10) {
                       printf("\n==========================================================================\n");

            printf("Lista de passageiros cheia. O passageiro será incluído na fila de espera.\n");

    if (ver != NULL) {
        // Verificar se a fila de espera está cheia
        fseek(ver, 0, SEEK_END);
        long tamanhoFilaEspera = ftell(ver);
        int numFilaEspera = tamanhoFilaEspera / sizeof(espera->numeroPassagem);
        if (numFilaEspera >= 5) {
            printf("Fila de espera cheia. O passageiro não pode ser cadastrado.\n");
                       printf("\n==========================================================================\n");

            fclose(ver);
            return 1;
        }
    }
            fclose(ler);
            fclose(ver);
            return 1;
        }
    }
    
    struct Passageiro novoPassageiro;
    
    printf("Digite o CPF do passageiro: ");
    scanf("%s", novoPassageiro.CPF);
    getchar();
  
    printf("Digite o nome do passageiro: ");
    scanf("%s", novoPassageiro.nome);
    getchar();
  
    printf("Digite o endereço do passageiro: ");
    scanf("%s", novoPassageiro.Endereco);
    getchar();
  
    printf("Digite o telefone do passageiro: ");
    scanf("%s", novoPassageiro.Telefone);
    getchar();
  
    printf("Digite o número da passagem do passageiro: ");
    scanf("%s", novoPassageiro.numeroPassagem);
    getchar();
  
    printf("Digite o número da poltrona do passageiro: ");
    scanf("%s", novoPassageiro.numeroPoltrona);
    getchar();
  
    printf("Digite o número do voo do passageiro: ");
    scanf("%s", novoPassageiro.numeroVoo);
    getchar();
  
    printf("Digite o horário do voo do passageiro: ");
    scanf("%s", novoPassageiro.horario);
    getchar();
  
    printf("Passageiro cadastrado com sucesso!\n");

  
    fclose(ler);
    fclose(ver);

  // chamando o main!
printf("\n\n\n");
main();
  
    return 0;
}

int excluirPassageiroSP() {
    char cpfRemovido[12];
    int mostrar;
    printf("Qual o CPF do passageiro que será removido?\n");
    scanf("%s", cpfRemovido);

    FILE* ler = fopen("voobhsp.txt", "r");
    if (ler == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }

    struct Passageiro pessoas[50];
    int numPassageiros = 0;
    int encontrou = 0;

    // Ler os passageiros do arquivo e procurar o passageiro a ser removido
    while (fscanf(ler, "%s %s %s %s %s %s %s %s",
                  pessoas[numPassageiros].CPF,
                  pessoas[numPassageiros].nome,
                  pessoas[numPassageiros].Endereco,
                  pessoas[numPassageiros].Telefone,
                  pessoas[numPassageiros].numeroPassagem,
                  pessoas[numPassageiros].numeroPoltrona,
                  pessoas[numPassageiros].numeroVoo,
                  pessoas[numPassageiros].horario) == 8 && numPassageiros < 50) {
        if (strcmp(pessoas[numPassageiros].CPF, cpfRemovido) == 0) {
            printf("\n\n\n");
            printf("PASSAGEIRO ENCONTRADO:\n\n");
            printf("|===================================================|\n");
            printf("CPF: %s\n", pessoas[numPassageiros].CPF);
            printf("Nome: %s\n", pessoas[numPassageiros].nome);
            printf("Endereço: %s\n", pessoas[numPassageiros].Endereco);
            printf("Telefone: %s\n", pessoas[numPassageiros].Telefone);
            printf("Número da Passagem: %s\n", pessoas[numPassageiros].numeroPassagem);
            printf("Número da Poltrona: %s\n", pessoas[numPassageiros].numeroPoltrona);
            printf("Número do Voo: %s\n", pessoas[numPassageiros].numeroVoo);
            printf("Horário: %s\n", pessoas[numPassageiros].horario);
            printf("|===================================================|\n");
            encontrou = 1;
            break;
        }
        numPassageiros++;
    }

    fclose(ler);

    if (!encontrou) {
        printf("Passageiro não encontrado.\n");
        // Chamando o main
        printf("\n\n\n");
        main();
        return 0;
    }

    FILE* escrever = fopen("voobhsp.txt", "w");
    if (escrever == NULL) {
        printf("Erro ao abrir o arquivo para reescrever a lista de passageiros.\n");
        return 1;
    }

    for (int i = 0; i < numPassageiros; i++) {
        if (strcmp(pessoas[i].CPF, cpfRemovido) != 0) {
            fprintf(escrever, "%s %s %s %s %s %s %s %s\n",
                    pessoas[i].CPF,
                    pessoas[i].nome,
                    pessoas[i].Endereco,
                    pessoas[i].Telefone,
                    pessoas[i].numeroPassagem,
                    pessoas[i].numeroPoltrona,
                    pessoas[i].numeroVoo,
                    pessoas[i].horario);
        }
    }

    fclose(escrever);

    printf("Passageiro removido com sucesso!\n");

    printf("Mostrar lista de passageiros? Sim = 1 / Não = 0: ");
    scanf("%d", &mostrar);
    if (mostrar) {
        ler = fopen("voobhsp.txt", "r");
        if (ler == NULL) {
            printf("Erro ao abrir o arquivo.\n");
            return 1;
        }

        printf("LISTA DE PASSAGEIROS:\n");

        numPassageiros = 0;
        while (fscanf(ler, "%s %s %s %s %s %s %s %s",
                      pessoas[numPassageiros].CPF,
                      pessoas[numPassageiros].nome,
                      pessoas[numPassageiros].Endereco,
                      pessoas[numPassageiros].Telefone,
                      pessoas[numPassageiros].numeroPassagem,
                      pessoas[numPassageiros].numeroPoltrona,
                      pessoas[numPassageiros].numeroVoo,
                      pessoas[numPassageiros].horario) == 8 && numPassageiros < 50) {
            printf("\n\n\n");
            printf("PASSAGEIRO:\n\n");
            printf("|===================================================|\n");
            printf("CPF: %s\n", pessoas[numPassageiros].CPF);
            printf("Nome: %s\n", pessoas[numPassageiros].nome);
            printf("Endereço: %s\n", pessoas[numPassageiros].Endereco);
            printf("Telefone: %s\n", pessoas[numPassageiros].Telefone);
            printf("Número da Passagem: %s\n", pessoas[numPassageiros].numeroPassagem);
            printf("Número da Poltrona: %s\n", pessoas[numPassageiros].numeroPoltrona);
            printf("Número do Voo: %s\n", pessoas[numPassageiros].numeroVoo);
            printf("Horário: %s\n", pessoas[numPassageiros].horario);
            printf("|===================================================|\n");
            numPassageiros++;
        }

        fclose(ler);
    }

    // Chamando o main
    printf("\n\n\n");
    main();

    return 0;
}

int mostrafiladeesperaSP(){
  FILE *ler = fopen("esperabhsp.txt", "r");


  while (!feof(ler)){
    struct Passageiro pessoas;

    fscanf(ler, "%s", pessoas.CPF);
    fscanf(ler, "%s", pessoas.nome);
    fscanf(ler, "%s", pessoas.Endereco);
    fscanf(ler, "%s", pessoas.Telefone);
    fscanf(ler, "%s", pessoas.numeroPassagem);
    fscanf(ler, "%s", pessoas.numeroPoltrona);
    fscanf(ler, "%s", pessoas.numeroVoo);
    fscanf(ler, "%s", pessoas.horario);

        // Imprimir os dados lidos
  printf("\n");
  printf("\n======================================================");
  printf("\nCPF: %s", pessoas.CPF);
  printf("\nNOME: %s", pessoas.nome);
  printf("\nEndereço: %s", pessoas.Endereco);
  printf("\nTELEFONE: %s", pessoas.Telefone);
  printf("\nNUMERO DE PASSAGEM: %s", pessoas.numeroPassagem);
  printf("\nNUMERO DE POLTRONA: %s", pessoas.numeroPoltrona);
  printf("\nNUMERO VOO: %s", pessoas.numeroVoo);
  printf("\nHORÁRIO DO VOO: %s", pessoas.horario);
  printf("\n======================================================");

}
fclose(ler);
printf("\n\n\n");
main();
  return 0;
};


// voos de brasilia

void PBH_BRASILIA(){
   FILE *ler = fopen("voobhBrasilia.txt", "r");


  while (!feof(ler)){
    struct Passageiro pessoas;

    fscanf(ler, "%s", pessoas.CPF);
    fscanf(ler, "%s", pessoas.nome);
    fscanf(ler, "%s", pessoas.Endereco);
    fscanf(ler, "%s", pessoas.Telefone);
    fscanf(ler, "%s", pessoas.numeroPassagem);
    fscanf(ler, "%s", pessoas.numeroPoltrona);
    fscanf(ler, "%s", pessoas.numeroVoo);
    fscanf(ler, "%s", pessoas.horario);

        // Imprimir os dados lidos
  printf("\n");
  printf("\n=============================================================");
  printf("\nCPF: %s", pessoas.CPF);
  printf("\nNOME: %s", pessoas.nome);
  printf("\nEndereço: %s", pessoas.Endereco);
  printf("\nTELEFONE: %s", pessoas.Telefone);
  printf("\nNUMERO DE PASSAGEM: %s", pessoas.numeroPassagem);
  printf("\nNUMERO DE POLTRONA: %s", pessoas.numeroPoltrona);
  printf("\nNUMERO VOO: %s", pessoas.numeroVoo);
  printf("\nHORÁRIO DO VOO: %s", pessoas.horario);
  printf("\n=============================================================");


}
fclose(ler);
printf("\n\n\n");
main();
};

int pesquisacpfBRASILIA() {
    FILE *ler = fopen("voobhBrasilia.txt", "r");
    
    if (ler == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }
    
    struct Passageiro pessoas[10];
    int numPassageiros = 0;  

    while (numPassageiros < 10 && fscanf(ler, "%s %s %s %s %s %s %s %s",
            pessoas[numPassageiros].CPF,
            pessoas[numPassageiros].nome,
            pessoas[numPassageiros].Endereco,
            pessoas[numPassageiros].Telefone,
            pessoas[numPassageiros].numeroPassagem,
            pessoas[numPassageiros].numeroPoltrona,
            pessoas[numPassageiros].numeroVoo,
            pessoas[numPassageiros].horario) == 8) {
        numPassageiros++;
    }
  
    char cpf[20];
    printf("Digite o CPF do passageiro: ");
    scanf("%s", cpf);
    cpf[strcspn(cpf, "\n")] = '\0';
    getchar();
    int encontrou = 0;
    
    for (int i = 0; i < numPassageiros; i++) {
        if (strcmp(pessoas[i].CPF, cpf) == 0) {  
            printf("\n===================================================\n");
            printf("Nome: %s\n", pessoas[i].nome);
            printf("Endereço: %s\n", pessoas[i].Endereco);
            printf("Telefone: %s\n", pessoas[i].Telefone);
            printf("Número da Passagem: %s\n", pessoas[i].numeroPassagem);
            printf("Número da Poltrona: %s\n", pessoas[i].numeroPoltrona);
            printf("Número do Voo: %s\n", pessoas[i].numeroVoo);
            printf("Horário: %s\n", pessoas[i].horario);
            printf("====================================================");
            encontrou = 1;
            break;
        } 
    }
    
    if (encontrou != 1){
        printf("Passageiro não encontrado!\n");
    }
    
    fclose(ler);

    // Chamando o main
    printf("\n\n\n");
    main();
    
    return 0;
}

int pesquisanomeBRASILIA(){
  FILE *ler = fopen("voobhBrasilia.txt", "r");
    
if (ler == NULL) {
  printf("Erro ao abrir o arquivo.\n");
  return 1;
    }
    
    struct Passageiro pessoas[10];
    int numPassageiros = 0;  

    while (numPassageiros < 10 && fscanf(ler, "%s %s %s %s %s %s %s %s",
  pessoas[numPassageiros].CPF,
  pessoas[numPassageiros].nome,
  pessoas[numPassageiros].Endereco,
  pessoas[numPassageiros].Telefone,
  pessoas[numPassageiros].numeroPassagem,
  pessoas[numPassageiros].numeroPoltrona,
  pessoas[numPassageiros].numeroVoo,
  pessoas[numPassageiros].horario) == 8) {
        numPassageiros++;
    }
  
char nome[20];
  printf("Digite o NOME do passageiro: ");
  scanf("%s", nome);
  nome[strcspn(nome, "\n")] = '\0';
  getchar();
  int encontrou = 0;
for (int i = 0; i < numPassageiros; i++) {
  if (strcmp(pessoas[i].nome, nome) == 0) {  
    printf("\n=======================================================\n");
    printf("CPF: %s\n", pessoas[i].CPF);
    printf("Nome: %s\n", pessoas[i].nome);
    printf("Endereço: %s\n", pessoas[i].Endereco);
    printf("Telefone: %s\n", pessoas[i].Telefone);
    printf("Número da Passagem: %s\n", pessoas[i].numeroPassagem);
    printf("Número da Poltrona: %s\n", pessoas[i].numeroPoltrona);
    printf("Número do Voo: %s\n", pessoas[i].numeroVoo);
    printf("Horário: %s\n", pessoas[i].horario);
    printf("=======================================================");
    encontrou =1;
    break;
  }  
}
if (encontrou != 1){
  printf("passageiro não encontrado!");
}
fclose(ler);

// chamando o main!
printf("\n\n\n");
main();
return 0;
}

int cadastroPassageiroBRASILIA() {
    FILE *ler = fopen("voobhBrasilia.txt", "r");
    FILE *ver = fopen("esperabhbrasilia.txt", "a");

    struct Passageiro espera[15];

    if (ler != NULL) {
        // Verificar se a lista de passageiros está cheia
        fseek(ler, 0, SEEK_END);
        long tamanhoListaPassageiros = ftell(ler);
        int numPassageiros = tamanhoListaPassageiros / sizeof(espera->numeroPoltrona);
        if (numPassageiros >= 10) {
                       printf("\n==========================================================================\n");

            printf("Lista de passageiros cheia. O passageiro será incluído na fila de espera.\n");

            // Verificar se a fila de espera está cheia
            fseek(ver, 0, SEEK_END);
            long tamanhoFilaEspera = ftell(ver);
            int numFilaEspera = tamanhoFilaEspera / sizeof(espera->numeroPassagem);
            if (numFilaEspera >= 5) {
                printf("Fila de espera cheia. O passageiro não pode ser cadastrado.\n");
                           printf("\n==========================================================================\n");

                fclose(ler);
                fclose(ver);
                return 1;
            }
        }
    }

    struct Passageiro novoPassageiro;

    printf("Digite o CPF do passageiro: ");
    scanf("%s", novoPassageiro.CPF);
    getchar();

    printf("Digite o nome do passageiro: ");
    scanf("%s", novoPassageiro.nome);
    getchar();

    printf("Digite o endereço do passageiro: ");
    scanf("%s", novoPassageiro.Endereco);
    getchar();

    printf("Digite o telefone do passageiro: ");
    scanf("%s", novoPassageiro.Telefone);
    getchar();

    printf("Digite o número da passagem do passageiro: ");
    scanf("%s", novoPassageiro.numeroPassagem);
    getchar();

    printf("Digite o número da poltrona do passageiro: ");
    scanf("%s", novoPassageiro.numeroPoltrona);
    getchar();

    printf("Digite o número do voo do passageiro: ");
    scanf("%s", novoPassageiro.numeroVoo);
    getchar();

    printf("Digite o horário do voo do passageiro: ");
    scanf("%s", novoPassageiro.horario);
    getchar();

    printf("Passageiro cadastrado com sucesso!\n");
               printf("\n==========================================================================\n");


    fprintf(ver, "%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n",
            novoPassageiro.CPF,
            novoPassageiro.nome,
            novoPassageiro.Endereco,
            novoPassageiro.Telefone,
            novoPassageiro.numeroPassagem,
            novoPassageiro.numeroPoltrona,
            novoPassageiro.numeroVoo,
            novoPassageiro.horario);

    fclose(ler);
    fclose(ver);

    // Chamando o main
    printf("\n\n\n");
    main();

    return 0;
}

int excluirPassageiroBRASILIA() {
    char cpfRemovido[12];
    int mostrar;
    printf("Qual o CPF do passageiro que será removido?\n");
    scanf("%s", cpfRemovido);

    FILE* ler = fopen("voobhBrasilia.txt", "r");
    if (ler == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }

    struct Passageiro pessoas[50];
    int numPassageiros = 0;
    int encontrou = 0;

    // Ler os passageiros do arquivo e procurar o passageiro a ser removido
    while (fscanf(ler, "%s %s %s %s %s %s %s %s",
                  pessoas[numPassageiros].CPF,
                  pessoas[numPassageiros].nome,
                  pessoas[numPassageiros].Endereco,
                  pessoas[numPassageiros].Telefone,
                  pessoas[numPassageiros].numeroPassagem,
                  pessoas[numPassageiros].numeroPoltrona,
                  pessoas[numPassageiros].numeroVoo,
                  pessoas[numPassageiros].horario) == 8 && numPassageiros < 50) {
        if (strcmp(pessoas[numPassageiros].CPF, cpfRemovido) == 0) {
            printf("\n\n\n");
            printf("PASSAGEIRO ENCONTRADO:\n\n");
            printf("|===================================================|\n");
            printf("CPF: %s\n", pessoas[numPassageiros].CPF);
            printf("Nome: %s\n", pessoas[numPassageiros].nome);
            printf("Endereço: %s\n", pessoas[numPassageiros].Endereco);
            printf("Telefone: %s\n", pessoas[numPassageiros].Telefone);
            printf("Número da Passagem: %s\n", pessoas[numPassageiros].numeroPassagem);
            printf("Número da Poltrona: %s\n", pessoas[numPassageiros].numeroPoltrona);
            printf("Número do Voo: %s\n", pessoas[numPassageiros].numeroVoo);
            printf("Horário: %s\n", pessoas[numPassageiros].horario);
            printf("|===================================================|\n");
            encontrou = 1;
            break;
        }
        numPassageiros++;
    }

    fclose(ler);

    if (!encontrou) {
        printf("Passageiro não encontrado.\n");
        // Chamando o main
        printf("\n\n\n");
        main();
        return 0;
    }

    FILE* escrever = fopen("voobhBrasilia.txt", "w");
    if (escrever == NULL) {
        printf("Erro ao abrir o arquivo para reescrever a lista de passageiros.\n");
        return 1;
    }

    for (int i = 0; i < numPassageiros; i++) {
        if (strcmp(pessoas[i].CPF, cpfRemovido) != 0) {
            fprintf(escrever, "%s %s %s %s %s %s %s %s\n",
                    pessoas[i].CPF,
                    pessoas[i].nome,
                    pessoas[i].Endereco,
                    pessoas[i].Telefone,
                    pessoas[i].numeroPassagem,
                    pessoas[i].numeroPoltrona,
                    pessoas[i].numeroVoo,
                    pessoas[i].horario);
        }
    }

    fclose(escrever);

    printf("Passageiro removido com sucesso!\n");

    printf("Mostrar lista de passageiros? Sim = 1 / Não = 0: ");
    scanf("%d", &mostrar);
    if (mostrar) {
        ler = fopen("voobhBrasilia.txt", "r");
        if (ler == NULL) {
            printf("Erro ao abrir o arquivo.\n");
            return 1;
        }

        printf("LISTA DE PASSAGEIROS:\n");

        numPassageiros = 0;
        while (fscanf(ler, "%s %s %s %s %s %s %s %s",
                      pessoas[numPassageiros].CPF,
                      pessoas[numPassageiros].nome,
                      pessoas[numPassageiros].Endereco,
                      pessoas[numPassageiros].Telefone,
                      pessoas[numPassageiros].numeroPassagem,
                      pessoas[numPassageiros].numeroPoltrona,
                      pessoas[numPassageiros].numeroVoo,
                      pessoas[numPassageiros].horario) == 8 && numPassageiros < 50) {
            printf("\n\n\n");
            printf("PASSAGEIRO:\n\n");
            printf("|===================================================|\n");
            printf("CPF: %s\n", pessoas[numPassageiros].CPF);
            printf("Nome: %s\n", pessoas[numPassageiros].nome);
            printf("Endereço: %s\n", pessoas[numPassageiros].Endereco);
            printf("Telefone: %s\n", pessoas[numPassageiros].Telefone);
            printf("Número da Passagem: %s\n", pessoas[numPassageiros].numeroPassagem);
            printf("Número da Poltrona: %s\n", pessoas[numPassageiros].numeroPoltrona);
            printf("Número do Voo: %s\n", pessoas[numPassageiros].numeroVoo);
            printf("Horário: %s\n", pessoas[numPassageiros].horario);
            printf("|===================================================|\n");
            numPassageiros++;
        }

        fclose(ler);
    }

    // Chamando o main
    printf("\n\n\n");
    main();

    return 0;
}

int mostrafiladeesperaBRASILIA() {
    FILE* ler = fopen("esperabhbrasilia.txt", "r");

    if (ler == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }

    struct Passageiro pessoas;

    int encontrou = 0;

    while (fscanf(ler, "%s %s %s %s %s %s %s %s",
                  pessoas.CPF,
                  pessoas.nome,
                  pessoas.Endereco,
                  pessoas.Telefone,
                  pessoas.numeroPassagem,
                  pessoas.numeroPoltrona,
                  pessoas.numeroVoo,
                  pessoas.horario) == 8) {
        encontrou = 1;
        // Imprimir os dados lidos
        printf("\n");
        printf("\n======================================================");
        printf("\nCPF: %s", pessoas.CPF);
        printf("\nNOME: %s", pessoas.nome);
        printf("\nEndereço: %s", pessoas.Endereco);
        printf("\nTELEFONE: %s", pessoas.Telefone);
        printf("\nNUMERO DE PASSAGEM: %s", pessoas.numeroPassagem);
        printf("\nNUMERO DE POLTRONA: %s", pessoas.numeroPoltrona);
        printf("\nNUMERO VOO: %s", pessoas.numeroVoo);
        printf("\nHORÁRIO DO VOO: %s", pessoas.horario);
        printf("\n======================================================");
    }

    fclose(ler);

    if (!encontrou) {
        printf("Nenhuma pessoa na fila de espera.\n");
    }

    // Chamando o main
    printf("\n\n\n");
    main();

    return 0;
}
