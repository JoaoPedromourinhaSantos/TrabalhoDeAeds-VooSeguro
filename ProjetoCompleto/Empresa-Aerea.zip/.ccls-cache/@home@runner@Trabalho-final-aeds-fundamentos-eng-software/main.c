#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

int main(void) {

  
printf("__  _ \n");
printf("\\ `/ |\n");
printf(" \\__`!\n");
printf(" / ,' `-.__________________\n");
printf("'-'\_____                LI`-.\n");
printf("   <____()-=O=O=O=O=O=[]====--)\n");
printf("     `.___ ,-----,_______...-' \n");
printf("          /    .'\n");
printf("         /   .'\n");
printf("        /  .'        \n");
printf("        `-'      \n");    
                
  
  
  
  
  
  
  return 0;
}